public class Player {

    private String name;
    private Person_information Person_information;
    private Club_Information Club_Information;

    public Player(String name, Person_information person_information, Club_Information club_Information) {
        this.name = name;
        this.Person_information = person_information;
        this.Club_Information = club_Information;
    }

    public String getName() {
        return name;
    }

    public Person_information getPerson_information() {
        return Person_information;
    }

    public Club_Information getClub_Information() {
        return Club_Information;
    }

    @Override
    public String toString() {
        return name + Person_information + Club_Information;
    }
}
