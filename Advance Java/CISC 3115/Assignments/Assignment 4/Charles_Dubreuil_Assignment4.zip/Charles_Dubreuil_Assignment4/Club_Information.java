public class Club_Information {
    private String team = "";
    private String position = "";


    public Club_Information(String team, String position) {
        this.team = team;
        this.position = position;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return "Club_Information => " + "Team " + team + ", " + "Position: " + position;


    }
}
