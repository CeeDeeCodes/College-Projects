import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TestPlayer {
    public static void main(String[] args) {

        String[] playerDetails = new String[6];
        ArrayList<Player> Players = new ArrayList<Player>();

        try {
            File myObj = new File("mlb_players.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);

                //removes the white spaces within each line of the input file
                String updatedPlayerData = data.replaceAll("\\s", "");

                playerDetails = updatedPlayerData.split(",");

                //System.out.println(Arrays.toString(playerDetails));

                String playerName = playerDetails[0];
                String playerTeam = playerDetails[1];
                String playerPosition = playerDetails[2];
                Double playerHeight = Double.valueOf(playerDetails[3]);
                Double playerWeight = Double.valueOf(playerDetails[4]);
                Double playerAge = Double.valueOf(playerDetails[5]);


                Person_information A = new Person_information(playerAge, playerHeight, playerWeight);
                Club_Information B = new Club_Information(playerTeam, playerPosition);
                Player C = new Player(playerName, A, B);

                Players.add(C);


            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        System.out.println("How many players are there in your arraylist? ");
        System.out.println(Players.size());

        System.out.println("How many players whose age is less than 25?");
        int totalPlayersUnder25 = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getAge() < 25)
                totalPlayersUnder25++;
        }
        System.out.println(totalPlayersUnder25);


        System.out.println("How many players whose age is less than 30 and greater than or\n" +
                "equal 25?");
        int totalPlayersUnder30andGreaterThan25 = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getAge() < 30 && P.getPerson_information().getAge() >= 25)
                totalPlayersUnder30andGreaterThan25++;
        }
        System.out.println(totalPlayersUnder30andGreaterThan25);


        System.out.println("How many players whose age is less than 40 greater than or equal 30?");
        int totalPlayersUnder40andGreaterThan30 = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getAge() < 40 && P.getPerson_information().getAge() >= 30)
                totalPlayersUnder40andGreaterThan30++;
        }
        System.out.println(totalPlayersUnder40andGreaterThan30);


        System.out.println("How many players whose bmi status in underweight?");
        int totalPlayersUnderWeight = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getBMIStatus().equals("Underweight")) {
                totalPlayersUnderWeight++;
            }
        }
        System.out.println(totalPlayersUnderWeight);


        System.out.println("How many players whose bmi status in healthy?");
        int totalPlayersHealthy = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getBMIStatus().equals("Healthy")) {
                totalPlayersHealthy++;
            }
        }
        System.out.println(totalPlayersHealthy);


        System.out.println("How many players whose bmi status in overweight?");
        int totalPlayersOverweight = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getBMIStatus().equals("Overweight")) {
                totalPlayersOverweight++;
            }
        }
        System.out.println(totalPlayersOverweight);


        System.out.println("How many players whose bmi status in obese?");
        int totalPlayersObese = 0;
        for (Player P : Players) {
            if (P.getPerson_information().getBMIStatus().equals("obese")) {
                totalPlayersObese++;
            }
        }
        System.out.println(totalPlayersObese);
    }
}
