import java.util.ArrayList;
import java.util.Collections;

public class KthSum {

    ArrayList<Integer> arr = new ArrayList<Integer>();
    int k = 0;

    public KthSum(int k, int[] nums) {
        this.k = k;
        for (int i : nums) arr.add(i);

    }

    public int add(int val) {
        arr.add(val);
        Collections.sort(arr);
        return arr.get(arr.size() - k) + arr.get(k-1);

    }
}

