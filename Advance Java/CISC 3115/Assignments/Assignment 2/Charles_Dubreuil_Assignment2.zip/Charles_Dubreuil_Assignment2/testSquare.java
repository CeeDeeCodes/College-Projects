
import java.util.Arrays;

public class testSquare {
    public static void main(String[] args) {

        square square1 = new square();
        System.out.println("The side of the square is: " + square1.side);
        System.out.println("The area of the square is: " + square1.getArea());
        System.out.println("The perimeter of the square is: " + square1.getPerimeter());
        System.out.println();

        square1.setSide(20);
        System.out.println("The side of the square is: " + square1.side);
        System.out.println("The area of the square is: " + square1.getArea());
        System.out.println("The perimeter of the square is: " + square1.getPerimeter());
        System.out.println();

        square square2 = new square(40);
        System.out.println("The side of the square is: " + square2.side);
        System.out.println("The area of the square is: " + square2.getArea());
        System.out.println("The perimeter of the square is: " + square2.getPerimeter());
        System.out.println();

        square2.setSide(80);
        System.out.println("The side of the square is: " + square2.side);
        System.out.println("The area of the square is: " + square2.getArea());
        System.out.println("The perimeter of the square is: " + square2.getPerimeter());

        int [] given_Point = {1,1};
        int [] change_Point = {2,4};
        square square3 = new square(20,given_Point);
        System.out.println("The center point is: " + Arrays.toString(square3.center_Point));
        square3.setCenter_Point(change_Point);
        System.out.println("The new center point is: " + Arrays.toString(square3.getCenter_Point()));
        System.out.println("The distance between the central point and point [1,1] is: "
                + square3.getDistance(given_Point));

        int[][] corner = square3.getSquare_Corners();
        System.out.println("The center points are:");
        for(int i =0; i < corner.length;i++){
            System.out.println( Arrays.toString(corner[i]));
        }

    }

}
