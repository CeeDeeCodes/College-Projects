public class square {


    public double side = 10;
    public int[] center_Point = {0, 0};


    public square() {
    }

    public square(double side) {
        this.side = side;
    }

    public square(int[] center_Point) {
        this.center_Point = center_Point;
    }

    public square(double side, int[] center_Point) {
        this.side = side;
        this.center_Point = center_Point;
    }


    public void setSide(double side) {
        this.side = side;
    }

    public void setCenter_Point(int[] center_Point) {
        this.center_Point = center_Point;
    }

    public double getArea() {

        return side * side;
    }


    public double getPerimeter() {
        return (side * 4);
    }

    public int[] getCenter_Point() {
        return center_Point;
    }

    public double getDistance(int[] other_point) {
        double x1 = center_Point[0];
        double y1 = center_Point[1];
        double x2 = other_point[0];
        double y2 = other_point[1];

        double distance = Math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));

        return distance;
    }

    public int[][] getSquare_Corners() {

        int[][] square_corners = new int[4][2];
        //point1
        square_corners[0][0] = center_Point[0] - (int) (side / 2);
        square_corners[0][1] = center_Point[1] - (int) (side / 2);

        //point2
        square_corners[1][0] = center_Point[0] + (int) (side / 2);
        square_corners[1][1] = center_Point[0] - (int) (side / 2);

        //point3
        square_corners[2][0] = center_Point[0] - (int) (side / 2);
        square_corners[2][1] = center_Point[0] + (int) (side / 2);

        //point4
        square_corners[3][0] = center_Point[0] + (int) (side / 2);
        square_corners[3][1] = center_Point[0] + (int) (side / 2);

        return square_corners;
    }
}

