public class question1 {


    public int answer(int[] nums) {

        int majorityElement = (nums.length / 2);

        for (int num : nums) {
            int counter = 0;
            for (int element : nums) {
                if (element == num) {
                    counter++;
                }
                if (counter > majorityElement) {
                    return num;
                }
            }
        }
        return -1;
    }
}
