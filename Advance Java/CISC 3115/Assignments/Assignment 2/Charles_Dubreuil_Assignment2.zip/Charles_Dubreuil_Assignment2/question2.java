public class question2 {

    public int answer(int[] nums) {

        int uniqueElementsSum = 0;

        for (int num : nums) {
            int counter = 0;
            for (int element : nums) {
                if (element == num) {
                    counter++;
                }
            }
            if (counter == 1) {
                uniqueElementsSum += num;
            }
        }
        return uniqueElementsSum;
    }
}
