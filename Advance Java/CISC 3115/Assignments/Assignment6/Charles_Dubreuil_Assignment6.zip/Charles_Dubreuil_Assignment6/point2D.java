public class point2D {

    private int x;
    private int y;

    public point2D() {
    }

    public point2D(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public double getDistance(point2D Point) {
        double x1 = this.x;
        double y1 = this.y;
        double x2 = Point.getX();
        double y2 = Point.getY();

        double distance = Math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));

        return distance;
    }

    @Override
    public String toString() {
        return "Point:" + "x=" + x + ",y=" + y;
    }
}


