public class point3D extends point2D {

    private int x;
    private int y;
    private int z;


    public point3D() {
    }

    public point3D(int x, int y) {
        super(x, y);
    }

    public point3D(int x, int y, int z) {

        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }

    public void setZ(int z) {
        this.z = z;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public double getDistance(point3D Point) {
        double x1 = this.x;
        double y1 = this.y;
        double z1 = this.z;
        double x2 = Point.getX();
        double y2 = Point.getY();
        double z2 = Point.getZ();

        double distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2));

        return distance;

    }

    @Override
    public String toString() {
        return "Point:" +"x=" + x +",y=" + y + ", z=" + z;
    }
}
