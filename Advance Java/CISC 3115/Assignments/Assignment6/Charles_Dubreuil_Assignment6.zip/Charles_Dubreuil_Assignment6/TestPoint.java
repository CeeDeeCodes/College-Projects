import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.*;

public class TestPoint {
    public static void main(String[] args) {

        //ArrayList to store all point object
        ArrayList<point2D> all2DPoint = new ArrayList<point2D>();
        ArrayList<point3D> all3DPoint = new ArrayList<point3D>();

        //Hashmap to remove all duplicated  point object
        HashMap<String, point2D> allDistinct2DPointMap = new HashMap<>();
        HashMap<String, point3D> allDistinct3DPointMap = new HashMap<>();

        ////ArrayList to store all distinct point object
        ArrayList<point2D> allDistinct2DPoint = new ArrayList<point2D>();
        ArrayList<point3D> allDistinct3DPoint = new ArrayList<point3D>();

        try {
            File myObj = new File("data.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();

                String[] Points = new String[3];

                Points = data.split(",");

                int X = Integer.parseInt(Points[0].replaceAll("[^0-9]", ""));
                int Y = Integer.parseInt(Points[1].replaceAll("[^0-9]", ""));

                if (Points.length > 2) {
                    int Z = Integer.parseInt(Points[2].replaceAll("[^0-9]", ""));
                    point3D A = new point3D(X, Y, Z);
                    all3DPoint.add(A);
                } else {
                    point2D B = new point2D(X, Y);
                    all2DPoint.add(B);
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        //Places all 2D points in arraylist into HashMap
        for (var entry : all2DPoint) {

            allDistinct2DPointMap.put(entry.toString(), entry);
        }

        //Places all 2D points in HashMap into Arraylist without duplicate
        var enterSet = allDistinct2DPointMap.entrySet();

        for (var entry : enterSet) {

            allDistinct2DPoint.add(entry.getValue());

        }

        //Places all 3D points in arraylist into HashMap
        for (var entry : all3DPoint) {

            allDistinct3DPointMap.put(entry.toString(), entry);

        }

        //Places all 3D points in HashMap into Arraylist without duplicate
        var enterSet2 = allDistinct3DPointMap.entrySet();
        for (var entry : enterSet2) {
            allDistinct3DPoint.add(entry.getValue());
        }


        System.out.println("How many distinct 2D points in the data.txt?");
        System.out.println(allDistinct2DPoint.size());


        System.out.println("How many distinct 3D points in the data.txt?");
        System.out.println(allDistinct3DPoint.size());


        point2D point_a = new point2D(-1, 1);
        Double total2DPointDistance2 = 0.0;
        for (var entry : allDistinct2DPoint) {
            System.out.println(entry + "\tDistance is: " + entry.getDistance(point_a));

            total2DPointDistance2 += entry.getDistance(point_a);

        }
        BigDecimal total2DPointDistance = new BigDecimal(total2DPointDistance2);
        System.out.println(total2DPointDistance);

        System.out.println();
        System.out.println();


        Double total3DPointDistance2 = 0.0;
        point3D point_b = new point3D(0, 10, -5);
        for (var entry : allDistinct3DPoint) {
            System.out.println(entry + "\t\tDistance is: " + entry.getDistance(point_b));

            total3DPointDistance2 +=entry.getDistance(point_b);
        }
        BigDecimal total3DPointDistance = new BigDecimal(total3DPointDistance2);
        System.out.println(total3DPointDistance);
    }
}
