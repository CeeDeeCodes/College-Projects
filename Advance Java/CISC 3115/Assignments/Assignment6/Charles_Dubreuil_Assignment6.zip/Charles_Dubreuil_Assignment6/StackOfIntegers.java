import java.util.ArrayList;

public class StackOfIntegers {
        //array, size default capacity

        private int[] elements;
        private int size;

        public static final int DEFAULT_CAPACITY =16;


        StackOfIntegers(){
            this.elements = new int[DEFAULT_CAPACITY];
            this.size =0;
        }

        StackOfIntegers(int newCapacity){
            this.elements = new int[newCapacity];
            this.size = 0;
        }

        public void toCopy(StackOfIntegers stack) {
            this.elements = stack.elements;
            this.size = stack.size;
        }

        public void toClear() {
            while (!this.empty()) {
                this.pop();
            }
        }

        public int getMax() {
            if (this.size == 0) {
                System.out.println("no value in the stack");
                return -1;
            }

            int maxNumber = Integer.MIN_VALUE;

            for (int i = 0; i < this.size; i++) {
                if (this.elements[i] > maxNumber) {
                    maxNumber = this.elements[i];
                }
            }

            return maxNumber;
        }

        public int getMin() {
            if (this.size == 0) {
                System.out.println("no value in the stack");
                return -1;
            }

            int minNumber = Integer.MAX_VALUE;

            for (int i = 0; i < this.size; i++) {
                if (this.elements[i] < minNumber) {
                    minNumber = this.elements[i];
                }
            }

            return minNumber;
        }

        public ArrayList<Integer> getDuplicate() {
            ArrayList<Integer> duplicated = new ArrayList<Integer>();

            for (int i = 0; i < this.size - 1; i++) {
                for (int j = i + 1; j < this.size; j++) {
                    if (this.elements[i] == this.elements[j]) {
                        if (!duplicated.contains(elements[i])) {
                            duplicated.add(elements[i]);
                        } else {
                            continue;
                        }
                    }
                }
            }

            if (duplicated.isEmpty()) {
                System.out.println("no duplicate");
                return duplicated;
            } else {
                return duplicated;
            }
        }

        //empty

        public boolean empty(){
            return this.size ==0;
        }

        //pop
        public int pop(){
            return elements[--size];
        }



        //peek
        public int peek(){
            int t =size;
            return elements[--t];
        }


        //push

        public void push(int value){
            if(this.size==elements.length){
                int []arr = new int[size*2];

                for(int i=0;i<size;i++)
                {
                    arr[i] = elements[i];
                }
                arr[size++] = value;

                elements = arr;

            }else{
                elements[size++] = value;
            }
        }


        //getSize()


        public int getSize(){

            return this.size;

        }
    }
