package application.assignment10;

public interface MathOperator {
    public float square(float number1);


    //sqrt root method
    public float sqrt(float number1);


    //factorial method
    public  float factorial(float number1);



    //abs method
    public float abs(float number1);

}
