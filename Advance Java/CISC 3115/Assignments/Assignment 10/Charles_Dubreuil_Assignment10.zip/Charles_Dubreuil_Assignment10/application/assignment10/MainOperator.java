package application.assignment10;

public class MainOperator extends BasicOperator implements MathOperator {

    @Override
    public float add(float number1, float number2) {
        // TODO Auto-generated method stub
        return number1 + number2;

    }

    @Override
    public float minus(float number1, float number2) {
        // TODO Auto-generated method stub
        return number1 - number2;
    }

    @Override
    public float divide(float number1, float number2) {
        return number1 / number2;
    }

    @Override
    public float multiply(float number1, float number2) {
        return number1 * number2;
    }

    @Override
    public float square(float number1) {
        // TODO Auto-generated method stub
        return number1 * number1;
    }


    @Override
    public float sqrt(float number1) {
        return (float) Math.sqrt(number1);
    }

    @Override
    public float factorial(float number1) {
        if (number1 <= 1) {
            return 1;
        } else {
            return number1 * factorial(number1 - 1);
        }
    }

    @Override
    public float abs(float number1) {
        return Math.abs(number1);
    }
}
