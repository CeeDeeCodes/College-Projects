package application.assignment10;

public abstract class BasicOperator {

    //add method
    public abstract float add(float number1, float number2);

    //minus method
    public abstract float minus(float number1, float number2);



    //divide method
    public abstract float divide(float number1, float number2);


    //multiply method
    public abstract float multiply(float number1, float number2);
}
