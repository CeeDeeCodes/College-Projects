public class square {

    //Initializes double variable "side" to the value 10"
    public double side = 10;


    //Empty constructor
    public square() {
    }

    // Constructor with double variable "side"
    public square(double side) {
        this.side = side;
    }

    //Setter for double variable "side"
    public void setSide(double side) {
        this.side = side;
    }

    //Returns the area of the square
    public double getArea() {

        return side * side;
    }

    //Return the perimeter of the square
    public double getPerimeter() {
        return (side * 4);
    }
}
