public class testSquare {

    public static void main(String[] args) {

        square square1 = new square();
        System.out.println("The side of the square is: " + square1.side);
        System.out.println("The area of the square is: " + square1.getArea());
        System.out.println("The perimeter of the square is: " + square1.getPerimeter());
        System.out.println();

        square1.setSide(20);
        System.out.println("The side of the square is: " + square1.side);
        System.out.println("The area of the square is: " + square1.getArea());
        System.out.println("The perimeter of the square is: " + square1.getPerimeter());
        System.out.println();

        square square2 = new square(40);
        System.out.println("The side of the square is: " + square2.side);
        System.out.println("The area of the square is: " + square2.getArea());
        System.out.println("The perimeter of the square is: " + square2.getPerimeter());
        System.out.println();

        square2.setSide(80);
        System.out.println("The side of the square is: " + square2.side);
        System.out.println("The area of the square is: " + square2.getArea());
        System.out.println("The perimeter of the square is: " + square2.getPerimeter());

    }
}
