public class solution1 {

    public int[] answer(int[] nums) {

        //Initializes int variable "n" to the length of "nums"
        int n = nums.length;

        //Create array "ans" and set its element capacity to 2n
        int[] ans = new int[2 * n];

        for (int i = 0; i < n; i++) {

            ans[i] = nums[i];

            ans[i + n] = nums[i];
        }
        return ans;
    }
}