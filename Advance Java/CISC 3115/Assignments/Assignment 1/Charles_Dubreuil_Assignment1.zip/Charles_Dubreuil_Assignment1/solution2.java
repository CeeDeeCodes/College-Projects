import java.util.stream.IntStream;

public class solution2 {

    public int maximumWealth(int[][] accounts) {

        //Initializes int variable "wealth" to Integer.MIN_VALUE
        int wealth = Integer.MIN_VALUE;


        for (int i = 0; i < accounts.length; i++) {

            //Calculate the sum of array
            int sum = IntStream.of(accounts[i]).sum();

            if (sum > wealth) {

                wealth = sum;
            }
        }

        return wealth;
    }
}