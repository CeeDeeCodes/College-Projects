public class Square {


    private double side = 10;
    private Point center_Point = new Point();


    public Square() {
    }

    public Square(double side) {
        this.side = side;
    }

    public Square(double side, Point center_Point) {
        this.side = side;
        this.center_Point = center_Point;
    }


    public void setSide(double side) {
        this.side = side;
    }


    public void setCenter_Point(Point center_Point) {
        this.center_Point = center_Point;
    }

    public Point getCenter_Point() {
        return center_Point;
    }

    public double getArea() {

        return this.side * this.side;
    }

    public double getPerimeter() {
        return (this.side * 4);
    }

    public double getDistance(Point other_point) {

        return this.center_Point.getDistance(other_point);
    }

    public Point[] getSquare_Corners() {
        Point[] square_corners = new Point[4];

        square_corners[0] = new Point();
        square_corners[1] = new Point();
        square_corners[2] = new Point();
        square_corners[3] = new Point();

        //point1
        square_corners[0].setX(this.center_Point.getX() - (int) (side / 2));
        square_corners[0].setY(this.center_Point.getY() + (int) (side / 2));

        //point2
        square_corners[1].setX(this.center_Point.getX() + (int) (side / 2));
        square_corners[1].setY(this.center_Point.getY() +(int) (side / 2));

        //point3
        square_corners[2].setX(this.center_Point.getX() + (int) (side / 2));
        square_corners[2].setY(this.center_Point.getY() - (int) (side / 2));

        //point4
        square_corners[3].setX(this.center_Point.getX() - (int) (side / 2));
        square_corners[3].setY(this.center_Point.getY() - (int) (side / 2));

        return square_corners;
    }

    public double getOverLappingArea(Square a) {
        Point[] arr1 = a.getSquare_Corners();
        Point[] arr2 = this.getSquare_Corners();

        double x_dist = (Math.min(arr1[1].getX(), arr2[1].getX())
                - Math.max(arr1[3].getX(), arr2[3].getX()));

        double y_dist = (Math.min(arr1[1].getY(), arr2[1].getY())
                - Math.max(arr1[3].getY(), arr2[3].getY()));

        double areaI = 0;
        if (x_dist > 0 && y_dist > 0) {
            areaI = x_dist * y_dist;

        }
        return areaI;


    }

    @Override
    public String toString() {
        return "Square Information:" + " point information:" + " x= " + center_Point.getX() + ", y= " +
                center_Point.getY() + ", side = " + side;
    }


}

