public class testSquare {
    public static void main(String[] args) {

        Point point1 = new Point(2, 2);
        Square square1 = new Square(4, point1);
        System.out.println(square1.toString());

        Point[] sc = square1.getSquare_Corners();
        for (int i = 0; i < sc.length; i++) {

            System.out.println("Square Corners " + (i + 1) + " " + sc[i].toString());

        }

        System.out.println();
        Square[] squareArray = new Square[3];

        Point point2 = new Point(5, 5);
        squareArray[0] = new Square(1.5, point2);

        point2 = new Point(1, 1);
        squareArray[1] = new Square(3, point2);

        squareArray[2] = new Square(2, point2);

        for (int i = 0; i < squareArray.length; i++) {

            System.out.println(squareArray[i].toString());

        }

        char a = 97;
        for (int i = 0; i < squareArray.length; i++) {

            double overlappingArea = square1.getOverLappingArea(squareArray[i]);
            System.out.println("overlapping area between square1 and square " +
                    a + " is: " + overlappingArea);
            a++;

        }
    }
}
