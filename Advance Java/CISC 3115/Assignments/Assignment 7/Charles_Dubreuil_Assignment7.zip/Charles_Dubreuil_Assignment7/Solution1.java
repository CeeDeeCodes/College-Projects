public class Solution1 {

    public int[][] matrixReshape(int[][] matrix, int r, int c) {

        if ((matrix.length * matrix[0].length) != r * c)
            return matrix;

        int m = 0, n = 0;
        int[][] ans = new int[r][c];

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (n >= c) {
                    m++;
                    n = 0;
                }
                ans[m][n++] = matrix[i][j];
            }
        }
        return ans;
    }
}

