import java.util.*;

public class Solution4 {
    public List<String> topKFrequent(String[] w, int k) {
        Map<String, Integer> nm = new HashMap<>();
        for (String p : w) {
            nm.put(p, nm.getOrDefault(p, 0) + 1);
        }
        List<Map.Entry<String, Integer>> kk = new ArrayList<>(nm.entrySet());
        Collections.sort(kk, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> s1, Map.Entry<String, Integer> s2) {
                int h = s2.getValue() - s1.getValue();
                if (h == 0) {
                    return s1.getKey().compareTo(s2.getKey());
                } else {
                    return h;
                }
            }
        });
        List<String> mm = new ArrayList<>();
        for (Map.Entry<String, Integer> l : kk) {
            if (k == 0)
                break;
            k--;
            mm.add(l.getKey());
        }
        return mm;
    }
}


