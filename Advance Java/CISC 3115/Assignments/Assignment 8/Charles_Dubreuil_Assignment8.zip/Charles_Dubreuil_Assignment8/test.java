import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class test {
    boolean exit;
    dynamicArray A = new dynamicArray();

    public static void main(String[] args) {

        test T = new test();
        T.runMenu();

    }

    public void runMenu() {
        printHeader();
        while (!exit) {
            printMenu();
            int choice = getInput();
            performAction(choice);
        }
    }

    private void printHeader() {
        System.out.println("+--------------------------------+");
        System.out.println("|             Menu               |");
        System.out.println("+--------------------------------+");
    }

    private void printMenu() {
        System.out.println("\nOptions:");
        System.out.println("1) Add Number");
        System.out.println("2) Get Number");
        System.out.println("3) Remove Number");
        System.out.println("4) Print Dynamic Array");
        System.out.println("5) Exit");
    }

    private int getInput() {
        Scanner sc = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 || choice > 5) {

            try {
                System.out.println("\nEnter Your Choice:");
                choice = Integer.parseInt(sc.nextLine());

                if (choice < 0 || choice > 5) {
                    System.out.println("Invalid Selection. Please Try Again.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid Selection. Please Try Again.");
            }
        }
        return choice;
    }


    private void performAction(int choice) {


        Scanner scanner = new Scanner(System.in);


        switch (choice) {
            case 1:

                try {
                    System.out.println("Enter Index:");
                    int index = scanner.nextInt();

                    System.out.println("Enter Value:");
                    int value = scanner.nextInt();
                    A.setElement(index, value);

                } catch (InputMismatchException e) {
                    System.out.println("Invalid Input you must enter an int [Returning to main menu...]");
                }
                break;

            case 2:

                try {
                    System.out.println("Enter Index:");
                    int index = scanner.nextInt();
                    A.getElement(index);

                } catch (InputMismatchException e) {
                    System.out.println("Invalid Input you must enter an int [Returning to main menu...]");
                }

                break;

            case 3:

                try {
                    System.out.println("Enter Index:");
                    int index = scanner.nextInt();
                    A.removeElements(index);

                } catch (InputMismatchException e) {
                    System.out.println("Invalid Input you must enter an int [Returning to main menu...]");
                }

                break;

            case 4:


                System.out.println(A.printInfo());


                break;

            case 5:
                exit = true;
                System.out.println("Exiting Program...");
                break;
        }
        //System.out.println(Arrays.toString(A.elements));
    }

}

