public class Person_information {


    private double age = 0;
    private double height = 0;
    private double weight = 0;

    public Person_information(double age, double height, double weight) {

        this.age = age;
        this.height = height;
        this.weight = weight;
    }

    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getBMI() {
        double KILOGRAMS_PER_POUND = 0.45359237; // Constant
        double METERS_PER_INCH = 0.0254; // Constant

        double new_weight = weight * KILOGRAMS_PER_POUND;
        double new_height = height * METERS_PER_INCH;

        return new_weight / (new_height) / (new_height);
    }


    public String getBMIStatus() {
        if (getBMI() < 18.5)
            return "Underweight";
        else if (getBMI() <= 24.9)
            return "Healthy";
        else if (getBMI() <= 29.9)
            return "Overweight";
        else
            return "obese";
    }

    @Override
    public String toString() {
        return "Person_information => Name: " +  " Age: " + age + " Height(inches): "
                + height + " Weight(lbs): " + weight;
    }
}
