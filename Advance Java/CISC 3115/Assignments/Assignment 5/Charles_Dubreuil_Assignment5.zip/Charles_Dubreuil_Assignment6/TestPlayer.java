import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TestPlayer {
    public static void main(String[] args) {


        String[] playerDetails = new String[6];
        ArrayList<Player> playerArrayList = new ArrayList<Player>();
        HashMap<String, Integer> teamHashmap = new HashMap<String, Integer>();
        HashMap<String, Integer> positionHashmap = new HashMap<String, Integer>();
        HashMap<String, HashMap<String, Integer>> countPosition_Team = new HashMap<String, HashMap<String, Integer>>();
        HashMap<String, HashMap<String, Integer>> countPosition_Team2 = new HashMap<String, HashMap<String, Integer>>();

        try {
            File myObj = new File("mlb_players.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);

                //removes the white spaces within each line of the input file
                //String updatedPlayerData = data.replaceAll("\\s", "");

                playerDetails = data.split(",");

                // System.out.println(Arrays.toString(playerDetails));


                String playerName = playerDetails[0];
                String playerTeam = playerDetails[1];
                String playerPosition = playerDetails[2];
                Double playerHeight = Double.valueOf(playerDetails[3]);
                Double playerWeight = Double.valueOf(playerDetails[4]);
                Double playerAge = Double.valueOf(playerDetails[5]);

                Person_information person_information = new Person_information(playerAge, playerHeight, playerWeight);
                Club_Information club_information = new Club_Information(playerTeam, playerPosition);
                Player player = new Player(playerName, person_information, club_information);

                //Add to ArrayList
                playerArrayList.add(player);

                //Add to Hashmap
                if (teamHashmap.containsKey(playerTeam)) {
                    int teamTotalPlayer = teamHashmap.get(playerTeam);
                    teamTotalPlayer++;
                    teamHashmap.put(playerTeam, teamTotalPlayer);
                } else {
                    teamHashmap.put(playerTeam, 1);
                }

                if (positionHashmap.containsKey(playerPosition)) {
                    int totalPlayerInPosition = positionHashmap.get(playerPosition);
                    totalPlayerInPosition++;
                    positionHashmap.put(playerPosition, totalPlayerInPosition);
                } else {
                    positionHashmap.put(playerPosition, 1);
                }

                if (countPosition_Team.get(playerTeam) != null) {
                    if (countPosition_Team.get(playerTeam).get(playerPosition) != null) {
                        countPosition_Team.get(playerTeam).put(playerPosition, countPosition_Team.get(playerTeam).get(playerPosition) + 1);
                    } else {
                        countPosition_Team.get(playerTeam).put(playerPosition, 1);
                    }
                } else {
                    HashMap<String, Integer> positions_buf = new HashMap<String, Integer>();
                    positions_buf.put(playerPosition, 1);

                    countPosition_Team.put(playerTeam, positions_buf);
                }

                if (countPosition_Team2.get(playerPosition) != null) {
                    if (countPosition_Team2.get(playerPosition).get(playerTeam) != null) {
                        countPosition_Team2.get(playerPosition).put(playerTeam, countPosition_Team2.get(playerPosition).get(playerTeam) + 1);
                    } else {
                        countPosition_Team2.get(playerPosition).put(playerTeam, 1);
                    }
                } else {
                    HashMap<String, Integer> positions_buf = new HashMap<String, Integer>();
                    positions_buf.put(playerTeam, 1);

                    countPosition_Team2.put(playerPosition, positions_buf);
                    
                }


            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


        System.out.println("How many players are there in your arraylist? ");
        System.out.println(playerArrayList.size());

        System.out.println("How many players whose age is less than 25?");
        int totalPlayersUnder25 = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getAge() < 25)
                totalPlayersUnder25++;
        }
        System.out.println(totalPlayersUnder25);


        System.out.println("How many players whose age is less than 30 and greater than or equal 25?");
        int totalPlayersUnder30andGreaterThan25 = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getAge() < 30 && P.getPerson_information().getAge() >= 25)
                totalPlayersUnder30andGreaterThan25++;
        }
        System.out.println(totalPlayersUnder30andGreaterThan25);


        System.out.println("How many players whose age is less than 40 greater than or equal 30?");
        int totalPlayersUnder40andGreaterThan30 = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getAge() < 40 && P.getPerson_information().getAge() >= 30)
                totalPlayersUnder40andGreaterThan30++;
        }
        System.out.println(totalPlayersUnder40andGreaterThan30);


        System.out.println("How many players whose bmi status in underweight?");
        int totalPlayersUnderWeight = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getBMIStatus().equals("Underweight")) {
                totalPlayersUnderWeight++;
            }
        }
        System.out.println(totalPlayersUnderWeight);


        System.out.println("How many players whose bmi status in healthy?");
        int totalPlayersHealthy = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getBMIStatus().equals("Healthy")) {
                totalPlayersHealthy++;
            }
        }
        System.out.println(totalPlayersHealthy);


        System.out.println("How many players whose bmi status in overweight?");
        int totalPlayersOverweight = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getBMIStatus().equals("Overweight")) {
                totalPlayersOverweight++;
            }
        }
        System.out.println(totalPlayersOverweight);


        System.out.println("How many players whose bmi status in obese?");
        int totalPlayersObese = 0;
        for (Player P : playerArrayList) {
            if (P.getPerson_information().getBMIStatus().equals("obese")) {
                totalPlayersObese++;
            }
        }
        System.out.println(totalPlayersObese);

        System.out.println();

        System.out.println("Total Player on each Team within MLG\n");
        var entrySet = teamHashmap.entrySet();
        for (var entry : entrySet) {
            System.out.println("Team:" + entry.getKey() + "--" + "Total Players:" + entry.getValue());

        }

        System.out.println();

        System.out.println("Total Player in each position within MLG\n");
        var entrySet2 = positionHashmap.entrySet();
        for (var entry : entrySet2) {
            System.out.println("Position:" + entry.getKey() + "--" + "Total Players:" + entry.getValue());
        }

        System.out.println();

        var entrySet3 = countPosition_Team.entrySet();
        for (var entry : entrySet3) {
            System.out.println("Team:" + entry.getKey() + "--" + "Players In Position :" + entry.getValue());
        }


        System.out.println();
        var entrySet4 = countPosition_Team2.entrySet();
        for (var entry : entrySet4) {
            System.out.println("Position:" + entry.getKey() + "--" + "Players In Position :" + entry.getValue());
        }

    }

}
