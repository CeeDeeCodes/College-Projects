public class solution1 {
    public String convert(String s, int numRows) {
        if (s == null) {
            throw new IllegalArgumentException();
        }
        if (numRows == 1) {
            return s;
        }
        StringBuilder str = new StringBuilder();

        int step = 2 * numRows - 2;

        for (int i = 0; i < numRows; i++) {

            if (i == 0 || i == numRows - 1) {

                for (int j = i; j < s.length(); j += step) {

                    str.append(s.charAt(j));
                }
            } else {

                int step2 = 2 * (numRows - i - 1);
                int step3 = step - step2;
                int k = i;
                boolean flag = true;

                while (k < s.length()) {
                    str.append(s.charAt(k));

                    if (flag) {
                        k += step2;
                        flag = false;
                    } else {
                        k += step3;
                        flag = false;
                    }

                }

            }
        }
        return str.toString();
    }
}

