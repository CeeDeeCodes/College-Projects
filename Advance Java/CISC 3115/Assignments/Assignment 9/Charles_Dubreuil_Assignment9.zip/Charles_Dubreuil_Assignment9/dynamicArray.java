import java.util.Currency;

public class dynamicArray {

    public int[] elements = new int[1];


    public void setElement(int index, int value) {

       /* try {


            int minimumIntTest = 0 / (value * value);


        } catch (ArithmeticException e) {
            System.out.println("You cannot set the value to the minimum int value");
            return;
        }*/

        try {
            checkValue(value);
        } catch (Exception e) {
            System.out.println("A problem occurred " +e);
            return;
        }

        try {

            elements[index] = value;

        } catch (ArrayIndexOutOfBoundsException e) {

            int[] newElements = new int[index + 1];

            for (int i = 0; i < elements.length; i++) {

                newElements[i] = elements[i];
            }

            elements = newElements;
            elements[index] = value;

            for (int i = 0; i < elements.length; i++) {

                if (elements[i] == 0) {
                    elements[i] = Integer.MIN_VALUE;
                }
            }
        }
    }

    public int getElement(int index) {
        try {

            int indexSelected = elements[index];

        } catch (ArrayIndexOutOfBoundsException e) {

            System.out.println("The index selected is out of bounds");
            return 0;

        }

        /*try {

            int A = elements[index];
            int minimumIntTest = 0 / (A * A);

        } catch (ArithmeticException e) {

            System.out.println("Value is not existing");
            return Integer.MIN_VALUE;
        }*/

        try {
            int A = elements[index];
            checkValue(A);
        } catch (Exception e) {
            System.out.println("A problem occurred " +e);
            return Integer.MIN_VALUE;
        }

        System.out.println("Index: " + index + ", Value: " + elements[index]);
        return elements[index];
    }

    public void removeElements(int index) {

        try {

            int indexSelected = elements[index];

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index is out of bounds");
            return;
        }

        /*try {

            int A = elements[index];
            int minimumIntTest = 0 / (A * A);

        } catch (ArithmeticException e) {

            System.out.println("The value cannot be removed because it doesn’t exist.");
            return;
        }*/

        try {
            int A = elements[index];
            checkValue(A);
        } catch (Exception e) {
            System.out.println("A problem occurred " +e);
            return;

        }


        elements[index] = Integer.MIN_VALUE;
    }

    public String printInfo() {

        String A = "";

        for (int i = 0; i < elements.length; i++) {
            if (elements[i] == Integer.MIN_VALUE) {
                continue;
            }

            A += " Index " + i + " => Value " + elements[i] + ",";


        }
        return A;
    }

    static void checkValue(int value) throws CustomException {


        try {
            int test = (0 / value * value);
        }
        catch(ArithmeticException e) {
            throw new CustomException("Invalid Element");
        }

    }
}

