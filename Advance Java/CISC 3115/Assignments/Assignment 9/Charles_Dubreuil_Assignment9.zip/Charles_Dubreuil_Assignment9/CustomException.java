public class CustomException extends Exception {
    CustomException(String message) {
        super(message);
    }
}
