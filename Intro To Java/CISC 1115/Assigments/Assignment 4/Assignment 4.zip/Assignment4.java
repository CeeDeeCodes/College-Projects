import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Assignment4 {

    public static void main(String[] args)throws FileNotFoundException, NoSuchElementException {

    //Read from file
    File file = new File("input.txt");



    introduction() ;

    int dataCounter = 0;

    int largestSum = Integer.MIN_VALUE;
    int smallestSum = Integer.MAX_VALUE;

    //Scanner scanner = new Scanner(System.in);

    //Initializes scanner to read from file
    Scanner scanner = new Scanner(file);





    //System.out.println("Enter first int:");
    int first = scanner.nextInt();

    //System.out.println("Enter second int:");
    int second = scanner.nextInt();

    // System.out.println("Enter third int:");
    int third = scanner.nextInt();

    //System.out.println("Enter fourth int:");
    int fourth = scanner.nextInt();

        while ((first + second) + (first + third) + (first + fourth) != 0) {

        System.out.println();
        System.out.println("\nThe four original integers are: " + first + "," + second + "," + third + "," + fourth);

        int sum = findSum(first, second, third, fourth);

        System.out.println("The sum is " + sum);

        printMyName(sum);

        int totalEvenNumber = howManyEven(first, second, third, fourth);

        System.out.print("There is/are " + totalEvenNumber + " even number(s)");


        dataCounter++;

        if (sum > largestSum ){
            largestSum = sum;
        }
        if (sum < smallestSum){
            smallestSum = sum;
        }

        //System.out.println("Enter first int:");
        first = scanner.nextInt();

        //System.out.println("Enter second int:");
        second = scanner.nextInt();

        // System.out.println("Enter third int:");
        third = scanner.nextInt();

        //System.out.println("Enter fourth int:");
        fourth = scanner.nextInt();
    }
        System.out.println("\n\n" + dataCounter + " sets of data was entered and processed");
        System.out.println("The largest sum computed is " + largestSum);
        System.out.println("The smallest sum computed is " + smallestSum);
}

    public static void introduction() throws FileNotFoundException {



        System.out.println("{To end program input 0 for all four input value}\n" +
                "(First) this program will take four int value from a user or file. \n(Secondly) this " +
                "program will compute the sum of three out of the four larger int inputted by a user or file and " +
                "subtract it from the smallest int out of the four value. \n(Thirdly) this program will print the name " +
                "inputted by a user or file the amount time whatever ever the sum of the 3 out out of the 4 largest " +
                "value \nsubtracted by the smallest int value is but however no less than 1 an no bigger that 12 amount of times" +
                "\n(lastly) this program will calculate the total even number inputted by the user/file" +
                " " +
                ".\n");
    }


    public static int findSum(int first, int second, int third, int fourth) {

        if (first > second && third > second && fourth > second) {

            return ((first + third + fourth) - second);

        } else if (second > first && third > first && fourth > first) {

            return ((second + third + fourth) - first);

        } else if (first > third && second > third && fourth > third) {

            return ((first + second + fourth) - third);

        } else {

            return ((first + second + third) - fourth);
        }
    }


    public static void printMyName(int sum) {

        if (sum < 1 || sum > 12) {
            System.out.println("it is not possible to print the name because it will print too many times");

        } else {
            for (int i = 1; i <= sum; i++) {
                System.out.println("Charles");

            }

        }

    }

    public static int howManyEven(int first, int second, int third, int fourth) {

        int evenNumberTotal = 0;

        if (first % 2 == 0) {
            evenNumberTotal++;
        }
        if (second % 2 == 0) {
            evenNumberTotal++;
        }
        if (third % 2 == 0) {
            evenNumberTotal++;
        }
        if (fourth % 2 == 0) {
            evenNumberTotal++;
        }

        return evenNumberTotal;
    }
}
