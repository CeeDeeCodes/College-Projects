import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Assignment3 {
    public static void main(String[] args) throws FileNotFoundException {

        //Write to file placed within PrintStream
        PrintStream ps = new PrintStream("output.txt");

        //Read from file
        File file = new File("input.txt");

        //Initializes scanner to read from file
        Scanner scanner = new Scanner(file);
        //Scanner scanner = new Scanner(System.in);

        //Initializes int variable id to the value "1"
        int id = 1;

        //Initializes double variable largestAverageScore to Integer.MIN_VALUE
        double largestAverageScore = Integer.MIN_VALUE;

        //Initializes int variable topAthlete to "0"
        int topAthlete = 0;

        while (id > 0) {
            //print message for user to enter athlete id
            System.out.println("\nEnter athlete id (enter -1 or less to stop):");

            //Set int variable id to number entered by user/file
            id = scanner.nextInt();

            //break out of while-loop when int variable id is less than 0
            if (id < 0) {
                break;
            }

            //print message for user to enter total judges scoring athlete
            System.out.println("enter total judges scoring current Athlete:");

            //Initializes int variable totalJudges to int enter in by user/file
            int totalJudges = scanner.nextInt();

            //Initializes double array scores with spaces equal to totalJudge value
            double[] scores = new double[totalJudges];

            //Initializes int variable counter to 0
            int counter = 0;

            for (int i = 0; i < totalJudges; i++) {

                //increment variable counter by 1 each time for loop is ran
                counter++;

                //print message for user to enter judges score for current athlete
                System.out.println("Enter Judge " + counter + " Score");

                //set spaces in score array to value entered by user/file
                scores[i] = scanner.nextDouble();
            }
            //Initializes double array athleteScore to scores array
            double[] athleteScores = scores;

            //Initializes double variable average to averageScore(athleteScores) return double
            double average = averageScore(athleteScores);

            //Keep track of athlete with largest averageScore
            if (average > largestAverageScore) {

                //Initializes double variable largestAverageScore to average
                largestAverageScore = average;

                //Initializes int variable topAthlete to id
                topAthlete = id;

            }
            //print message of athlete id number and average score
            ps.printf("\nAthlete: %d, Average Score: %.2f", id, average);
        }
        //print message of athlete with largest average score id and average score
        ps.printf("\n\nAthlete: %d, has the highest Average Score: %.2f ", topAthlete, largestAverageScore);
    }

    public static double averageScore(double[] array) {

        //Initializes double array judgeScores to array value
        double[] judgeScores = array;

        //Initializes double variable largestScore to Integer.MIN_VALUE
        double largestScore = Integer.MIN_VALUE;

        //Initializes double variable smallestScore to Integer.MAX_VALUE
        double smallestScore = Integer.MAX_VALUE;

        //Initializes double variable score
        double score;

        //Initializes double variable total to 0
        double total = 0;

        //Initializes double variable smallAndBigScore to 1
        double smallAndBigScore = 1;


        for (int i = 0; i < array.length; i++) {
            score = judgeScores[i];

            //Keep track of largest score
            if (score > largestScore) {

                //Initializes double variable largestScore to score
                largestScore = score;

            }
            //Keep track of smallest averageScore
            if (score < smallestScore) {

                //Initializes double variable smallestScore to score
                smallestScore = score;

            }

            //increment double variable total by  double variable score value
            total += score;

            // Add up the smallest score with the Largest Score
            smallAndBigScore = smallestScore + largestScore;
        }
        return (total - smallAndBigScore) / (array.length - 2);
    }
}

