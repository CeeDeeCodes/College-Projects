import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class Assignment2 {
    public static void main(String[] args) throws IOException {

        try {

            //Write to file placed within PrintStream
            PrintStream ps = new PrintStream("output.txt");

            //BufferedWriter bufferWriter = new BufferedWriter(new FileWriter("output.txt"));
            File file = new File("input.txt");

            //Initializes scanner to read from file
            Scanner scanner = new Scanner(file);
            //Scanner scanner = new Scanner(System.in);

            //Initializes i variable id to the value 1"
            int id = 1;

            //Initializes int variable wins"
            int wins;

            //Initializes int variable losses"
            int losses;

            //Initializes int variable totalGamesPlayed"
            int totalGamesPlayed;

            //Initializes int variable remainingGames"
            int remainingGames;

            //Initializes int variable winningAverage"
            double winningAverage;

            //Initializes string variable A
            String A;

            //Initializes string variable B"
            String B;


            while (id > 0) {

                //print message for user to enter team id
                System.out.println("\nEnter Team id (enter -1 or less to stop):");

                //Set id variable to number entered by user/file
                id = scanner.nextInt();

                //print message when id less than 0 has been entered
                if (id < 0) {
                    ps.printf("\nSentinel has been entered");
                    break;
                }

                //print message for user to enter total team wins
                System.out.println("Enter Team \"" + id + "\" total Wins");

                //Set wins variable to number entered by user/file
                wins = scanner.nextInt();

                //print message for user to enter total team losses
                System.out.println("Enter Team \"" + id + "\" total Losses");

                //Set losses variable to number entered by user/file
                losses = scanner.nextInt();

                //Set TotalGamesPlayed variable to wins plus losses
                totalGamesPlayed = wins + losses;


                // Set remainingGames Variable to 25 total games in season minus variable totalGamesPlayed value
                remainingGames = 25 - totalGamesPlayed;

                //Set winningAverage variable to wins divided by totalGamesPlayed
                winningAverage = (double) wins / totalGamesPlayed;

                if (remainingGames == wins) {

                    //print message if team games remaining is equal to total wins
                    A = "number of games remaining is equal to number won";
                } else {

                    //print message if team game remaining is greater to total wins
                    A = "number of games remaining is greater than number won";
                }

                if (remainingGames > losses) {

                    //print message if team remaining is equal to total losses
                    B = "number of games remaining is greater than number lost\n";
                } else {

                    //print message if team games remaining is less to total losses
                    B = "number of games remaining is not greater than number lost\n";
                }

                //print team data
                ps.printf("\nTeam %d \n%d wins %d losses \ntotal number of games played is " +
                                "%d     %d games remaining \nthe number average is %.4f\n%s\n%s"
                        , id, wins, losses, totalGamesPlayed, remainingGames, winningAverage, A, B);
            }

            //closes scanner
            scanner.close();
            //closes file
            ps.close();

        } catch (IOException exception) {
            return;
        }
    }
}
