import java.io.*;

public class Assignment1 {

    public static void main(String[] args) throws FileNotFoundException {


        try {
            //Write to file placed within PrintStream
            PrintStream ps = new PrintStream("output.txt");
            //BufferedWriter bufferWriter = new BufferedWriter(new FileWriter("output.txt"));


            //Initializes variable titleOne to "X Values:"
            String titleOne = "X Values:";
            //Initializes variable titleTwo to "Y Values:"
            String titleTwo = "Y Values:";
            //Initializes variable titleThree to "Message:"
            String titleThree = "Message:";

            //Print intro to program
            ps.println("Charles Dubreuil, This is the output of my first program\n");

            //print table for values and messages
            ps.printf("%1s%12s%14s\n", titleOne, titleTwo, titleThree);


            //counter for each y value that is zero
            int zeroCounter = 0;
            //counter for each y value that is positive
            int positiveCounter = 0;
            //counter for each y value that is negative
            int negativeCounter = 0;
            //Initializes x value of closest  y value to zero
            double savedX = 0;
            //Initializes value of closest y value to zero
            double closestNumber = Integer.MAX_VALUE;


            for (double x = -3.0; x <= 3.0; x += 0.5) {

                //Initializes message variable to empty string
                String message = "";

                //Initializes xTableLabel variable to "X = "
                String xTableLabel = "X = ";

                //Initializes yTableLabel variable to empty string "Y = "
                String yTableLabel = "Y = ";

                //Formula for GPA calculation
                double y = (4 * Math.pow(x, 3) + 8 * Math.pow(x, 2) - 31 * x - 35)
                        / (Math.pow((3 * Math.pow(x, 2) + 1), 1 / 2) + (2 * Math.abs(x - 1.5)));

                //Increments zeroCounter variable by 1 and set message variable equal to " Y IS ZERO"
                if (y == 0) {
                    zeroCounter++;
                    message = " Y IS ZERO";

                    //Increments positiveCounter variable by 1 and set message variable equal to " Y IS POSITIVE"
                } else if (y > 0) {
                    positiveCounter++;
                    message = " Y IS POSITIVE";

                    //Increments negativeCounter variable by 1 and set message variable equal to " Y IS NEGATIVE"
                } else if (y < 0) {
                    negativeCounter++;
                    message = " Y IS NEGATIVE";

                }


                //print table format depending on x Value
                if (x < 0) {
                    ps.printf("X =%.1f \tY = %.1f \t%s\n", x, y, message);
                } else {
                    ps.printf("X = %.1f \tY = %.1f \t%s\n", x, y, message);
                }


                //Check to see weather variable y is the closest to zero and then set it equal to variable closeNumber
                if (Math.abs(0 - closestNumber) > Math.abs(0 - y) && y != 0) {
                    closestNumber = y;
                    savedX = x;
                }
            }

            //Print Conclusion
            ps.println("\nMy first program is complete");

            ps.println();
            //print closest Y value to zero message
            ps.printf("The closest Y value to zero is %.1f , the x value which gives this value is %.1f and the Y value is %.1f places away from zero \n", closestNumber, savedX, closestNumber);
            //print amount of time Y value is positive
            ps.println("There were " + positiveCounter + " Positive Y results");
            //print amount of time Y value is negative
            ps.println("There were " + negativeCounter + " Negative Y results");
            //print amount of time Y value is zero
            ps.println("There were " + zeroCounter + " Zero Y results");

            //close printStream
            ps.close();

            //Return exception
        } catch (IOException exception) {
            return;
        }
    }
}

