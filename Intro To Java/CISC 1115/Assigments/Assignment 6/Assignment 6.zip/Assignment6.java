import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Assignment6 {

    public static void main(String[] args)throws FileNotFoundException {


        File file = new File("input.txt");

        Scanner sc = new Scanner(file);
        System.out.println("Enter Array Size:");
        int size = sc.nextInt();
        double[] originalArray = new double[0];

        originalArray = readData(size, originalArray);

        System.out.println("Here is the original array");
        printArray(size, originalArray);

        double average = findAverage(size, originalArray);

        double[] newArray = howFarAway(size,average,originalArray);

        System.out.println("Here is the new array");
        printArray(size, newArray);

    }

    public static double[] readData(int n, double[] numbers) throws FileNotFoundException {
        File file = new File("input2.txt");

        Scanner sc = new Scanner(file);

        numbers = new double[n];

        for (int i = 0; i < n; i++) {

            System.out.println("Enter Array Value [" + i + "]");
            numbers[i] = sc.nextDouble();
        }
        return numbers;
    }

    public static void printArray(int q, double[] numb) {

        int counter = 0;
        for (int i = 0; i < q; i++) {

            System.out.printf("%.1f  ", numb[i]);

            counter++;
            if (counter != 1 && counter % 5 == 0) {

                System.out.println();
            }
        }
    }

    public static double findAverage(int k, double[] p) {

        double total = 0;
        for (int i = 0; i < k; i++) {

            total += p[i];

        }
        System.out.println("\nThe average of this array is " + (total / k));
        return (total / k);
    }

    public static double[] howFarAway(int m, double average, double[] r) {

        double[] s = new double[m];

        for (int i = 0; i < m; i++) {

            s[i] = (r[i] - average);

        }
        return s;
    }}



