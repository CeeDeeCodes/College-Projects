

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Assignment5 {

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Number less than 0 or greater than 6 to end program");
        System.out.println();

        System.out.println("Enter a number between 1 through 6 for die 1");
        int die1 = sc.nextInt();

        System.out.println("Enter a number between 1 through 6 for die 2");
        int die2 = sc.nextInt();


        while (die1 >= 0 && die1 <= 6 && die2 >= 0 && die2 <= 6) {

            System.out.println("Die1: " + die1 + "\nDie2: " + die2);

            int sum = outCome(die1, die2);

            if (sum != 7 && sum != 11 && sum != 2 && sum != 12) {

                outCome2(sum);

            }


            System.out.println("\nEnter Number less than 0 or greater than 6 to end program");

            System.out.println("Enter a number between 1 through 6 for die 1");
            die1 = sc.nextInt();

            System.out.println("Enter a number between 1 through 6 for die 2");
            die2 = sc.nextInt();

        }

        System.out.println("Program has halted");

    }

    public static int outCome(int inputOne, int inputTwo) {

        int sum = inputOne + inputTwo;

        if (sum == 7 || sum == 11 || sum == 2 || sum == 12) {
            System.out.println("The player has won, both dice add up to " + sum);
            return sum;
        } else {
            System.out.println("The player has lost and must roll again, both dice add up to " + sum);
            return sum;
        }
    }

    public static void outCome2(int target) {


        Scanner sc = new Scanner(System.in);

        System.out.println("\nPlayer must roll a " + target + " to win, However if they roll a 7 they lose");
        System.out.println("Enter number between 1 through 6 for die 1");
        int die1 = sc.nextInt();

        System.out.println("Enter number between 1 through 6 for die 2");
        int die2 = sc.nextInt();


        while ((die1 + die2) != 7 && (die1 + die2) != target) {


            System.out.println("Player must roll again");

            System.out.println("Enter another number between 1 through 6 for die 1");
            die1 = sc.nextInt();

            System.out.println("Enter another number between 1 through 6 for die 2");
            die2 = sc.nextInt();
        }

        if ((die1 + die2) == 7) {
            System.out.println("Player has lost the roll added up to 7");
        } else {
            System.out.println("Player has won dice add up to previous roll value which is " + target);
        }

    }

}

