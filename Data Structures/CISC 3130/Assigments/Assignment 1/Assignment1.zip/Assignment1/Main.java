import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Main {
    
    private static Scanner sc = null;
    private static FileWriter fw = null;

    public static void main(String[] args) {
        try {
            sc = new Scanner(System.in);
            try {
                fw = new FileWriter("output.txt");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            System.out.println("Enter parameter: ");
            int size = sc.nextInt();

            double numbers[] = new double[size];

            readData(size, numbers);

            fw.append("\n\nHere is the original array:");
            printArray(size, numbers);

            double avg = findAverage(size, numbers);
            fw.append("\n\nAverage is =" + avg);

            double howFar[] = howFarAway(size, avg, numbers);
            fw.append("\n\nHere is the new array:");
            printArray(size, howFar);

            avg = findAverage(size, howFar);
            fw.append("\n\nAverage is =" + avg);


            sc.close();
            fw.close();
            System.out.println("Data processed successfully. Please see generated output.txt file");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void readData(int n, double[] numbers) throws IOException {
        sc = new Scanner(new File("input.txt"));
        fw.append("\nPrinting file Contents:");
        int counter = 0;
        while (sc.hasNext()) {
            String data = sc.next();
            fw.append("\n" + data);
            if (counter < n) {
                numbers[counter] = Double.parseDouble(data);
                counter++;
            }
        }
    }

    private static void printArray(int q, double[] numb) throws IOException {
        for (int i = 0; i < q; i++) {
            if (i % 5 == 0) {
                fw.append("\n");
            }
            fw.append(String.format("%20s", numb[i] + ""));
        }
    }

    private static double findAverage(int k, double[] p) {
        double total = 0;
        for (int i = 0; i < k; i++) {
            total = total + p[i];
        }

        return k != 0 ? (total / k) : 0;
    }

    private static double[] howFarAway(int m, double avg, double[] r) throws IOException {
        double[] s = new double[m];
        for (int i = 0; i < m; i++) {
            s[i] = r[i] - avg;
        }

        return s;
    }


}






