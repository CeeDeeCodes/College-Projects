public class Node {
    String name;
    Node leftChild;
    Node rightChild;
    public Node(String name) { this.name = name; }

}
