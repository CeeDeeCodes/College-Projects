public class BinaryTree {
    Node root;

    public BinaryTree() { root = null; }

    public void traverseTree(Node root) {  // inorder traverse
        if (root != null) {
            traverseTree(root.leftChild);
            System.out.print(root.name + " ");
            traverseTree(root.rightChild);
        }
    }
    int count = 2;
    public void findMax(Node p){

        if(p.rightChild != null){
            p = p.rightChild;
            System.out.print("\n"+ p.name+":" + " is son # "+ count +";" );
            count++;
        }
    }
    public void findYoungestSon(Node p){
        if(p.leftChild != null){
            p = p.leftChild;
            System.out.println(p.name);
        }
    }
    public void findSonsOf(Node p){
        try {
            System.out.print(p.name + " ");
            if (p != null){
                p = p.leftChild;
                System.out.print("had the son(s): "+ "\n" +p.name+":" + " ");
                System.out.print("is the oldest son, ");
                if(p.rightChild != null){
                    findMax(p);
                    findMax(p.rightChild);
                }
            }
            System.out.println(" is the youngest son ");
        } catch (NullPointerException e){
            System.out.println("has no sons");
        }
    }
}