

public class Main {


    public static void main(String[] args) {

        BinaryTree tree = new BinaryTree();


        tree.root = new Node("grandMother");

        tree.root.leftChild = new Node("Mother"); // first daughter of grandMother
        tree.root.leftChild.leftChild = new Node("Sister");
        tree.root.leftChild.leftChild.rightChild = new Node("Me");
        tree.root.leftChild.leftChild.rightChild.rightChild = new Node("Sister");

        tree.root.leftChild.rightChild = new Node("aunt 1"); // second son of grandfather
        tree.root.leftChild.rightChild.leftChild = new Node("cousin");
        tree.root.leftChild.rightChild.leftChild.leftChild = new Node("baby cousin");
        tree.root.leftChild.rightChild.leftChild.rightChild =  new Node("cousin 2");

        tree.root.leftChild.rightChild.rightChild = new Node("aunt 2"); // third son of grandfather
        tree.root.leftChild.rightChild.rightChild.leftChild = new Node("cousin 3");
        tree.root.leftChild.rightChild.rightChild.leftChild.rightChild = new Node("cousin 4");

        tree.findSonsOf(tree.root); // p would grandfather, or can be change based on the data above

        // QUESTION ANSWERED:
        // who are the sons of p?
        // who is the oldest son?
        // who is the youngest son?
    }


}







