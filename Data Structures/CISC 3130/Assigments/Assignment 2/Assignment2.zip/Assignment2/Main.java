import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {

    public static void main(String[] args) {

        HashMap<Integer, Customer> customers2 = new HashMap<>();

        try {

            File masterFile = new File("MasterFile.txt");
            FileReader fileReader = new FileReader(masterFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;

            String splitter = "(\\s)+";

            while ((line = bufferedReader.readLine()) != null) {

                String[] columns = line.trim().split(splitter);

                int customerNumber = Integer.parseInt(columns[0].trim());
                String customerName = columns[1].trim();
                double balanceDue = Double.parseDouble(columns[2].trim());
                Customer customer = new Customer(customerName, customerNumber, balanceDue);


                if (customers2.containsKey(customerNumber)) {
                    continue;
                } else {
                    customers2.put(customerNumber, customer);
                }

                File transactionFile = new File("TransactionFile.txt");
                FileReader transactionFileReader = new FileReader(transactionFile);
                BufferedReader transactionBufferedReader = new BufferedReader(transactionFileReader);
                String transactionLine;


                while ((transactionLine = transactionBufferedReader.readLine()) != null) {
                    String[] splited = transactionLine.trim().split(splitter);

                    char code = splited[0].trim().toUpperCase().charAt(0);
                    int customerNum = Integer.parseInt(splited[1].trim());

                    if (customerNum != customer.getCustomerNumber())
                        continue;


                    switch (code) {
                        case 'P': {
                            int transactionNumber = Integer.parseInt(splited[2].trim());
                            double amount = Double.parseDouble(splited[3].trim());

                            if (splited.length == 5) {
                                int discountAmount = Integer.parseInt(splited[4].trim());
                                Transaction transaction = new Payment(transactionNumber, amount, discountAmount);
                                customer.addTranscation(transaction);
                            } else {
                                Transaction transaction = new Payment(transactionNumber, amount);
                                customer.addTranscation(transaction);
                            }

                            break;
                        }

                        case 'O': {

                            int transactionNumber = Integer.parseInt(splited[2].trim());
                            String item = splited[3].trim();
                            int quantity = Integer.parseInt(splited[4].trim());
                            double cost = Double.parseDouble(splited[5].trim());

                            if (splited.length == 7) {
                                int discountAmount = Integer.parseInt(splited[6].trim());
                                Transaction transaction = new Order(transactionNumber, item, quantity, cost, discountAmount);
                                customer.addTranscation(transaction);
                            } else {
                                Transaction transaction = new Order(transactionNumber, item, quantity, cost);
                                customer.addTranscation(transaction);
                            }

                            break;
                        }

                    }

                }

                transactionBufferedReader.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {

            FileWriter fstream = new FileWriter("output.txt");
            BufferedWriter out = new BufferedWriter(fstream);

            for (Customer customer : customers2.values()) {

                customer.updateBalanceDue();

                out.write(customer.Print());
            }

            out.close();

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
