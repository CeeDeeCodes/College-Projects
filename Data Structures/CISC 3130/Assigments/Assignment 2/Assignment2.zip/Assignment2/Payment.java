public class Payment extends Transaction {
    private double amount;
    private double discountAmount;

    public Payment(int transactionNumber, double amount) {
        super(transactionNumber);
        this.amount = amount;
        this.discountAmount = 0;
    }

    public Payment(int transactionNumber, double amount, double discountAmount) {
        super(transactionNumber);
        this.amount = amount;

        if (discountAmount >= 0 && discountAmount <= 30) {

            this.discountAmount = discountAmount;
        } else {
            this.discountAmount = 0;
        }
    }

    public double getAmount() {
        double percentage = amount * (discountAmount / 100);
        return (amount - percentage);
    }

    @Override
    public String toString() {
        return super.toString() + "\tPayment\t" + "\t\t\t" +  "$"+getAmount() + "\n";
    }
}
