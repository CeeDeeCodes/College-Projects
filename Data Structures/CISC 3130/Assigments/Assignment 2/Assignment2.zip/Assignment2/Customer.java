import java.util.ArrayList;

public class Customer {
    private String customerName;
    private int customerNumber;
    private double balanceDue;
    private double previousBalance;
    private ArrayList<Transaction> Transactions;

    public Customer(int customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Customer(String customerName, int customerNumber, double balanceDue) {
        this.customerName = customerName;
        this.customerNumber = customerNumber;
        this.balanceDue = balanceDue;
        this.previousBalance = balanceDue;
        this.Transactions = new ArrayList<>();
    }


    public void addTranscation(Transaction transaction) {
        Transactions.add(transaction);
    }

    public void updateBalanceDue() {
        for (Transaction transaction : Transactions) {
            if (transaction instanceof Order) { //checking if this is order
                Order order = (Order) transaction;
                balanceDue += order.getTotalCost(); //adding due
            } else if (transaction instanceof Payment) { //checking if this is payment
                Payment payment = (Payment) transaction;
                balanceDue -= payment.getAmount(); //deducing due
            }
        }
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public double getPreviousBalance() {
        return previousBalance;
    }

    public double getBalanceDue() {
        return balanceDue;
    }

    public ArrayList<Transaction> getTransactions() {
        return Transactions;
    }

    @Override
    public String toString() {
        return "Customer [Customer Name=" + customerName + ",Customer Number =" + customerNumber + ", Balance Due=" + balanceDue + "]";
    }

    public String Print() {
        String output = "";
        output = output + getCustomerName() + "\t" + getCustomerNumber() + "\n\n\t\t\t\t\t\t\t\t" + "PREVIOUS BALANCE \t$" + getPreviousBalance() + "\n\n";

        for (Transaction trans : Transactions) {
            output = output + trans.toString();
        }
        output = output + "\n\n\t\t\t\t\t\t\t\t" + "BALANCE DUE\t$" + getBalanceDue() + "\n";
        return output;
    }

}



