public abstract class Transaction {
    int transactionNumber;

    public Transaction(int transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public int getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(int transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    @Override
    public String toString() {
        return "Transaction Number "+getTransactionNumber()+"      ";
    }

}
