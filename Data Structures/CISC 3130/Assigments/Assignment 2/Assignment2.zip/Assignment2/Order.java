public class Order extends Transaction {

    private String item;
    private int quantity;
    private double itemCost;
    private double discountAmount;


    public Order(int transactionNumber, String item, int quantity, double itemCost) {
        super(transactionNumber);
        this.item = item;
        this.quantity = quantity;
        this.itemCost = itemCost;
        this.discountAmount = 0;
    }

    public Order(int transactionNumber, String item, int quantity, double itemCost, double discountAmount) {
        super(transactionNumber);
        this.item = item;
        this.quantity = quantity;
        this.itemCost = itemCost;

        if (discountAmount >= 5 && discountAmount <= 30) {
            this.discountAmount = discountAmount;
        } else {
            this.discountAmount = 0;
        }
    }


    public double getTotalCost() {
        double percentage = (itemCost * quantity) * (discountAmount / 100);
        return (itemCost * quantity) - percentage;
    }

    public String getItem() {
        return item;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getItemCost() {
        return itemCost;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }
    @Override
    public String toString() {
        return super.toString()+"\t"+getItem()+" Ordered "+ "     "+"$"+getTotalCost()+"\n";
    }
}



