import java.util.Scanner;

public class sorts {

    public static void main(String args[]) {
        int n;
        System.out.print("Enter the size of the array:");
        n = in.nextInt();
        int input[] = new int[n];
        // Displaying the results
        input = takingDataFromUser(n);
        System.out.println("Bubble Sort");
        bubbleSort(input, n);
        System.out.println("Quick Sort");
        quickSort(input, 0, n - 1);
        System.out.println("Comparisions:" + quickComp);
        System.out.println("InterChanges:" + quickInterChange);
        System.out.println("Merge Sort");
        ms(input, 0, n - 1);
        System.out.println("Comparisions:" + mergeComp);
        System.out.println("InterChanges:" + mergeInterChange);
    }




    private static Scanner in = new Scanner(System.in);

    private static int quickComp = 0, quickInterChange = 0, mergeComp = 0, mergeInterChange = 0;

    private static int[] takingDataFromUser(int n) {
        // This function is used to take the data from the user and returns the array
        int temp[] = new int[n];
        System.out.println("Enter the values");
        for (int i = 0; i < n; i++) temp[i] = in.nextInt();
        return temp;
    }

    private static void bubbleSort(int a[], int n) {
        // This function is used to sort the array using bubble sort
        int temp, comp = 0, interChange = 0;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                comp += 1;
                if (a[j] > a[j + 1]) {
                    // Swapping the elements
                    interChange += 1;
                    temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }
        System.out.println("Comparisions:" + comp);
        System.out.println("InterChanges:" + interChange);
    }

    private static int partition(int a[], int low, int high) {
        // This function is used to ensure that all elements which are left to pivot is less than the pivot and right elements is to greater
        int temp, pivot = a[high];
        int i = low - 1;
        for (int j = low; j <= high - 1; j++) {
            quickComp += 1;
            if (a[j] <= pivot) {
                // Swapping the elements
                quickInterChange += 1;
                i++;
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        temp = a[i + 1];
        a[i + 1] = a[high];
        a[high] = temp;
        return i + 1;
    }

    private static void quickSort(int a[], int low, int high) {
        // This function is used to sort the array using quick sort
        if (low < high) {
            int p = partition(a, low, high);
            // Calling partition for getting pivot element
            quickSort(a, low, p - 1);
            quickSort(a, p + 1, high);
            // Calling quickSort recursively to sort the array

        }
    }

    private static void merge(int a[], int l, int m, int r) {
        // In this function we will merge two sorted sub arrays
        int i, j, k;
        int n1 = m - l + 1, n2 = r - m;
        int L[] = new int[n1], R[] = new int[n2];
        for (i = 0; i < n1; i++) L[i] = a[l + i];
        for (j = 0; j < n2; j++) R[j] = a[m + j + 1];
        i = 0;
        j = 0;
        k = l;
        mergeComp += 1;
        while (i < n1 && j < n2) {
            mergeInterChange += 1;
            // Swapping the elements
            if (L[i] <= R[j]) a[k++] = L[i++];
            else a[k++] = R[j++];
        }
        while (i < n1) a[k++] = L[i++];
        while (j < n2) a[k++] = R[j++];
    }

    private static void ms(int a[], int l, int r) {
        // This function is used to sort the array using merge sort
        if (l < r) {
            int m = l + (r - l) / 2;
            ms(a, l, m);
            // Calling ms recursively to sort the array
            ms(a, m + 1, r);
            merge(a, l, m, r);
            // Calling merge for merging two sorted sub arrays
        }
    }


}