public class Stock {
    double quantity;
    double price;

    public Stock(double q, double p) {
        price = p;
        quantity = q;
    }
}