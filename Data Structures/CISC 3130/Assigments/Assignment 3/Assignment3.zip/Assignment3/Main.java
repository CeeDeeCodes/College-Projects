import java.io.*;
import java.text.DecimalFormat;
import java.util.LinkedList;


public class Main {

    public static void main(String[] args) {

// 2 linkedlist to store stocks
        LinkedList<Stock> oakStock = new LinkedList<>();
        LinkedList<Stock> cherryMapleStock = new LinkedList<>();

        // current promotion value;
        double promotion = 0d;

        // formatter to print values at 2 decimal points
        DecimalFormat df = new DecimalFormat("#.00");


        try {

            File input = new File("input.txt");
            FileReader fileReader = new FileReader(input);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;

            BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"));

            // this is regex format for spaces
            String splitter = "(\\s)+";

            while ((line = bufferedReader.readLine()) != null) {


                String[] columns = line.trim().split(splitter);

                char code = columns[0].trim().toUpperCase().charAt(0);


                switch (code) {

                    // execute buying
                    case 'R': {
                        double widgetAmount = Integer.parseInt(columns[2].trim());
                        String removeChar = columns[3].trim().replaceFirst("[^0-9]", "");
                        double price = Double.parseDouble(removeChar);


                        if (columns[1].equals("O")) {
                            oakStock.add(new Stock(widgetAmount, price));
                        } else {
                            cherryMapleStock.add(new Stock(widgetAmount, price));
                        }

                        System.out.println("Received new stock at price:" + "$" + price);
                        writer.write("Received new stock at price:" + "$" + price);
                        writer.write("\n");


                        break;
                    }


                    //executes selling
                    case 'S': {
                        String ans = "";
                        double oakQuantity = Double.parseDouble(columns[2]);
                        double temp = oakQuantity;
                        double total = 0;

                        if (columns[1].equals("O")) {
                            while (oakQuantity > 0 && !oakStock.isEmpty()) {
                                Stock stock = oakStock.pollFirst();
                                double stockQuantity;
                                double stockPrice;

                                if (oakQuantity >= stock.quantity) {
                                    oakQuantity -= stock.quantity;
                                    stockPrice = stock.price * 1.6;
                                    stockQuantity = stock.quantity;

                                } else {
                                    stockPrice = stock.price * 1.6;
                                    stockQuantity = oakQuantity;
                                    oakStock.add(0, new Stock(stock.quantity - oakQuantity, stock.price));
                                    oakQuantity = 0;
                                }

                                total += (stockQuantity * stockPrice);
                                ans += (stockQuantity + " at " + df.format(stockPrice) + " each Sales: $ " + df.format(stockQuantity * stockPrice)) + "\n";
                            }

                            total = total * (1 - promotion);
                            ans += "Total Sale: $ " + df.format(total) + "\n";
                            ans = (temp - oakQuantity) + " Widgets sold\n" + ans;

                            if (oakQuantity > 0) {
                                ans += "Remainder of " + oakQuantity + " pieces of Oak or (Cherry Maple) wood not available\n";
                            }

                            System.out.println(ans);
                            writer.write(ans);
                            writer.write("\n");
                        } else {
                            while (oakQuantity > 0 && !cherryMapleStock.isEmpty()) {
                                Stock stock = cherryMapleStock.pollFirst();
                                double stockQuantity;
                                double stockPrice;

                                if (oakQuantity >= stock.quantity) {
                                    oakQuantity -= stock.quantity;
                                    stockPrice = stock.price * 1.6;
                                    stockQuantity = stock.quantity;

                                } else {
                                    stockPrice = stock.price * 1.6;
                                    stockQuantity = oakQuantity;
                                    cherryMapleStock.add(0, new Stock(stock.quantity - oakQuantity, stock.price));
                                    oakQuantity = 0;
                                }
                                total += (stockQuantity * stockPrice);
                                ans += (stockQuantity + " at " + df.format(stockPrice) + " each Sales: $ " + df.format(stockQuantity * stockPrice)) + "\n";
                            }

                            total = total * (1 - promotion);
                            ans += "Total Sale: $ " + total + "\n";
                            ans = (temp - oakQuantity) + " Widgets sold\n" + ans;
                            if (oakQuantity > 0) {
                                ans += "Remainder of " + oakQuantity + " pieces of Oak or (Cherry Maple) wood not available\n";
                            }
                            System.out.println(ans);
                            writer.write(ans);
                            writer.write("\n");
                        }
                        promotion = 0;

                        break;

                    }
                    case 'P': {

                        String removeChar = columns[1].trim().replaceFirst("[^0-9]", "");

                        promotion = Integer.parseInt(removeChar);
                        System.out.println("New promotion rate is: " + df.format(promotion) + "%");
                        writer.write("New promotion rate is: " + df.format(promotion) + "%");
                        writer.write("\n");
                        promotion /= 100d;
                        break;
                    }
                }
            }

            if (!oakStock.isEmpty()) {
                writer.write("\n");
                System.out.println("AVAILABLE STOCK FOR OAK");
                System.out.println("QUANTITY PRICE");
                writer.write("AVAILABLE STOCK FOR OAK\n");
                writer.write("QUANTITY PRICE\n");
                while (!oakStock.isEmpty()) {
                    Stock stock = oakStock.pollFirst();
                    writer.write(stock.quantity + " $" + stock.price);
                    writer.write("\n");
                    System.out.println(stock.quantity + " $" + stock.price);

                }
            }

            if (!cherryMapleStock.isEmpty()) {
                writer.write("\n");
                System.out.println("AVAILABLE STOCK FOR CHERRY MAPLE");
                System.out.println("QUANTITY PRICE");
                writer.write("AVAILABLE STOCK FOR CHERRY MAPLE\n");
                writer.write("QUANTITY PRICE\n");
                while (!cherryMapleStock.isEmpty()) {
                    Stock stock = cherryMapleStock.pollFirst();
                    writer.write(stock.quantity + " $" + stock.price);
                    writer.write("\n");
                    System.out.println(stock.quantity + " $" + stock.price);
                }
            }

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println();
    }

}
